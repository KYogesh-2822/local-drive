<?php

namespace App\Http\Controllers\Admin\Content;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Content\UpdateContentSectionRequest;
use App\Models\Content\ContentPage;
use App\Models\Content\ContentPageSection;
use App\Models\Content\ContentSectionItem;
use App\Services\Content\HtmlSanitizer;
use App\Services\Content\ImageUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PageSectionController extends Controller
{
    public function update(UpdateContentSectionRequest $request, ContentPage $page, ContentPageSection $section, HtmlSanitizer $sanitizer)
    {
        $this->assertBelongsToPage($page, $section);
        $data = $request->validated();
        $data['body_html'] = $sanitizer->sanitize($data['body_html'] ?? null);
        $data['is_enabled'] = $request->boolean('is_enabled');
        $section->update($data);

        return back()->with('message', 'Section updated successfully.');
    }

    public function storeItem(Request $request, ContentPage $page, ContentPageSection $section, ImageUploadService $images, HtmlSanitizer $sanitizer)
    {
        $this->assertBelongsToPage($page, $section);
        $data = $this->validateItem($request);
        $data['body'] = $sanitizer->sanitize($data['body'] ?? null);
        $data['is_enabled'] = $request->boolean('is_enabled', true);
        $data['sort_order'] = ((int) $section->items()->max('sort_order')) + 1;

        if ($request->hasFile('image')) {
            $data['image'] = $images->store($request->file('image'), 'content/pages/'.$page->slug.'/items');
        }

        $section->items()->create($data);

        return back()->with('message', 'Section item added successfully.');
    }

    public function updateItem(Request $request, ContentPage $page, ContentPageSection $section, ContentSectionItem $item, ImageUploadService $images, HtmlSanitizer $sanitizer)
    {
        $this->assertBelongsToPage($page, $section);
        abort_unless($item->content_page_section_id === $section->id, 404);
        $data = $this->validateItem($request);
        $data['body'] = $sanitizer->sanitize($data['body'] ?? null);
        $data['is_enabled'] = $request->boolean('is_enabled');

        if ($request->hasFile('image')) {
            $data['image'] = $images->store(
                $request->file('image'),
                'content/pages/'.$page->slug.'/items',
                $item->image
            );
        }

        $item->update($data);

        return back()->with('message', 'Section item updated successfully.');
    }

    public function destroyItem(ContentPage $page, ContentPageSection $section, ContentSectionItem $item)
    {
        $this->assertBelongsToPage($page, $section);
        abort_unless($item->content_page_section_id === $section->id, 404);

        if ($item->image && str_starts_with($item->image, 'content/')) {
            Storage::disk('public')->delete($item->image);
        }
        $item->delete();

        return back()->with('message', 'Section item removed successfully.');
    }

    private function validateItem(Request $request): array
    {
        return $request->validate([
            'title' => ['nullable', 'string', 'max:255'],
            'subtitle' => ['nullable', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'image_alt' => ['nullable', 'string', 'max:255'],
            'button_label' => ['nullable', 'string', 'max:100'],
            'button_url' => ['nullable', 'string', 'max:500'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_enabled' => ['nullable', 'boolean'],
        ]);
    }

    private function assertBelongsToPage(ContentPage $page, ContentPageSection $section): void
    {
        abort_unless($section->content_page_id === $page->id, 404);
    }
}
