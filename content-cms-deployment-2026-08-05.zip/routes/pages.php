<?php

use App\Http\Controllers\Content\PageController;
use App\Http\Controllers\Content\SitemapController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

$managedPageSlugs = array_keys(config('content.system_pages', []));

Route::get('/new-{page}', [PageController::class, 'preview'])
    ->whereIn('page', $managedPageSlugs)
    ->name('content.review.show');

if (config('content.managed_pages_live')) {
    Route::get('/', [PageController::class, 'home'])->name('content.home');
    Route::get('/locations/{page}', [PageController::class, 'location'])->name('content.locations.show');
} else {
    Route::get('/', [HomeController::class, 'index'])->name('home');
}

Route::get('/sitemap.xml', SitemapController::class)->name('content.sitemap');
