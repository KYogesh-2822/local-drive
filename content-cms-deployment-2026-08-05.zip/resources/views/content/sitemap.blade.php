{!! '<'.'?xml version="1.0" encoding="UTF-8"?'.'>' !!}
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
@foreach($pages as $page)
    <url><loc>{{ $page->publicUrl() }}</loc><lastmod>{{ $page->updated_at->toAtomString() }}</lastmod></url>
@endforeach
@foreach($posts as $post)
    <url><loc>{{ $post->publicUrl() }}</loc><lastmod>{{ $post->updated_at->toAtomString() }}</lastmod></url>
@endforeach
</urlset>
