@extends('layouts.main')

@push('styles')<link rel="stylesheet" href="{{ asset('css/content-pages.css') }}">@endpush

@section('content')
@php
    $image = $post->featured_image;
    if ($image && !str_starts_with($image, 'http')) $image = str_starts_with($image, 'content/') ? asset('storage/'.$image) : asset(ltrim($image, '/'));
@endphp
<article class="managed-content-page managed-article">
    <header class="managed-article__header">
        <div class="container managed-article__header-inner">
            <span class="managed-eyebrow">{{ optional($post->category)->name ?: 'Travel Guide' }}</span>
            <h1>{{ $post->title }}</h1>
            <p>{{ $post->excerpt }}</p>
            <div class="managed-article__meta">
                <span>By {{ $post->author_name }}</span>
                <time datetime="{{ optional($post->published_at)->toDateString() }}">{{ optional($post->published_at)->format('F j, Y') }}</time>
            </div>
        </div>
    </header>
    <div class="container managed-article__layout">
        @if($image)<img class="managed-article__featured" src="{{ $image }}" alt="{{ $post->featured_image_alt }}">@endif
        <div class="managed-article__body managed-rich-text">{!! $post->body_html !!}</div>
    </div>
    @include('content.sections.faq', ['heading' => 'Frequently Asked Questions'])
    <section class="managed-cta">
        <div class="container-fluid managed-cta__inner">
            <div><span class="managed-eyebrow">Plan your journey</span><h2>Ready to explore Jordan?</h2><p>Choose a vehicle that matches your route, passengers and luggage.</p></div>
            <a class="managed-button" href="{{ route('reservation') }}">Book Now</a>
        </div>
    </section>
</article>
@include('content.partials.structured-data', ['breadcrumbs' => [['name' => 'Home', 'url' => url('/')], ['name' => 'Blog', 'url' => url('/blog')], ['name' => $post->title, 'url' => $post->publicUrl()]]])
@endsection
