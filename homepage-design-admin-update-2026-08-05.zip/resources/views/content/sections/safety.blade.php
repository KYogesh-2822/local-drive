<section class="fleet-section">
    <div class="container">
        <div class="section-title text-center">
            @if($section->heading)
                <h2 class="custom_heading">{{ $section->heading }}</h2>
            @endif
            @if($section->subheading)
                <p class="custom_para">{{ $section->subheading }}</p>
            @endif
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-6 col-sm-12">
                <ul class="safety-list">
                    @foreach($section->activeItems as $item)
                        @php($itemText = $item->title ?: trim(strip_tags($item->body ?? '')))
                        @if($itemText !== '')
                            <li>{{ $itemText }}</li>
                        @endif
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</section>
