<section class="standard-section">
    <div class="container section-container">
        <div class="section-title text-center">
            @if($section->heading)
                <h2 class="custom_heading">{{ $section->heading }}</h2>
            @endif
            @if($section->subheading)
                <p class="custom_para">{{ $section->subheading }}</p>
            @endif
        </div>
        @foreach($section->activeItems->chunk(2) as $row)
            <div class="row justify-content-center {{ $loop->first ? '' : 'mt-4' }}">
                @foreach($row as $item)
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="destination-card">
                            @if($item->title)<h4>{{ $item->title }}</h4>@endif
                            @if($item->body)<div class="destination-card__description">{!! $item->body !!}</div>@endif
                        </div>
                    </div>
                @endforeach
            </div>
        @endforeach
    </div>
</section>
