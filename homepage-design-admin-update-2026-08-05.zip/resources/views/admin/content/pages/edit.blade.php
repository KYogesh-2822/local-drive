@extends('layouts.admin.header-content')

@section('content')
<section class="dashboard content-admin">
    <div class="common-heading d-flex justify-content-between align-items-center">
        <div><h1>Edit {{ $page->name }}</h1><p class="mb-0"><code>{{ $page->slug }}</code> · Review URL: {{ route('content.review.show', $page) }}</p></div>
        <div>
            <a class="btn btn-outline-secondary" href="{{ route('admin.content.pages.index') }}">Back</a>
            <a class="btn btn-outline-success" href="{{ route('admin.content.pages.preview', ['page' => $page->slug]) }}" target="_blank">Preview</a>
        </div>
    </div>
    @include('admin.content.partials.alerts')

    <ul class="nav nav-tabs mt-4" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#pageSettings" type="button">Page & SEO</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#pageSections" type="button">Content Sections</button></li>
    </ul>

    <div class="tab-content pt-4">
        <div class="tab-pane fade show active" id="pageSettings">
            <form action="{{ route('admin.content.pages.update', ['page' => $page->slug]) }}" method="post" enctype="multipart/form-data" class="card card-body">
                @csrf @method('PUT')
                <div class="row">
                    <div class="col-md-8 mb-3"><label class="form-label">Admin page name</label><input class="form-control" name="name" value="{{ old('name', $page->name) }}" required></div>
                    <div class="col-md-4 mb-3"><label class="form-label">Status</label><select class="form-select" name="status"><option value="draft" @selected($page->status === 'draft')>Draft</option><option value="published" @selected($page->status === 'published')>Published</option></select></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Hero image</label><input class="form-control" type="file" name="hero_image" accept="image/jpeg,image/png,image/webp">@if($page->hero_image)<small class="text-muted">Current: {{ $page->hero_image }}</small>@endif</div>
                    <div class="col-md-6 mb-3"><label class="form-label">Hero image alt text</label><input class="form-control" name="hero_image_alt" value="{{ old('hero_image_alt', $page->hero_image_alt) }}"></div>
                    <div class="col-12"><hr><h3 class="h5">Search engine metadata</h3></div>
                    <div class="col-12 mb-3"><label class="form-label">Meta title</label><input class="form-control" name="meta_title" maxlength="255" value="{{ old('meta_title', $page->meta_title) }}" required></div>
                    <div class="col-12 mb-3"><label class="form-label">Meta description</label><textarea class="form-control" name="meta_description" rows="3" required>{{ old('meta_description', $page->meta_description) }}</textarea></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Focus keyword</label><input class="form-control" name="focus_keyword" value="{{ old('focus_keyword', $page->focus_keyword) }}"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">Canonical URL</label><input class="form-control" type="url" name="canonical_url" value="{{ old('canonical_url', $page->canonical_url) }}"></div>
                    <div class="col-12"><hr><h3 class="h5">Blogs displayed on this page</h3></div>
                    @php $selectedBlogs = old('blog_ids', $page->blogPosts->pluck('id')->all()); @endphp
                    @forelse($posts as $post)
                        <div class="col-md-6 mb-2"><label class="form-check"><input class="form-check-input" type="checkbox" name="blog_ids[]" value="{{ $post->id }}" @checked(in_array($post->id, $selectedBlogs))><span class="form-check-label">{{ $post->title }} <small>({{ $post->status }})</small></span></label></div>
                    @empty
                        <div class="col-12"><p class="text-muted">No blog posts are available yet.</p></div>
                    @endforelse
                </div>
                <div><button class="btn btn-success" type="submit">Save Page Settings</button></div>
            </form>
        </div>

        <div class="tab-pane fade" id="pageSections">
            <div class="accordion" id="sectionAccordion">
                @foreach($page->sections as $section)
                    <div class="accordion-item mb-3 border">
                        <h2 class="accordion-header" id="sectionHeading{{ $section->id }}">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#section{{ $section->id }}">
                                {{ $sectionLabels[$section->section_key] ?? $section->section_key }}
                                <span class="badge ms-2 {{ $section->is_enabled ? 'bg-success' : 'bg-secondary' }}">{{ $section->is_enabled ? 'Enabled' : 'Hidden' }}</span>
                            </button>
                        </h2>
                        <div id="section{{ $section->id }}" class="accordion-collapse collapse" data-bs-parent="#sectionAccordion">
                            <div class="accordion-body">
                                <form action="{{ route('admin.content.sections.update', ['page' => $page->slug, 'section' => $section->id]) }}" method="post" class="row">
                                    @csrf @method('PUT')
                                    <div class="col-md-6 mb-3"><label class="form-label">Heading</label><input class="form-control" name="heading" value="{{ $section->heading }}"></div>
                                    <div class="col-md-6 mb-3"><label class="form-label">Subheading</label><input class="form-control" name="subheading" value="{{ $section->subheading }}"></div>
                                    @if($section->section_key !== 'safety')
                                        <div class="col-12 mb-3"><label class="form-label">Section content</label><textarea class="form-control summernote" name="body_html" rows="5">{{ $section->body_html }}</textarea></div>
                                    @endif
                                    <div class="col-12 mb-3"><label class="form-check"><input type="hidden" name="is_enabled" value="0"><input class="form-check-input" type="checkbox" name="is_enabled" value="1" @checked($section->is_enabled)><span class="form-check-label">Display this section</span></label></div>
                                    <div class="col-12"><button class="btn btn-success" type="submit">Save Section</button></div>
                                </form>

                                @if($section->section_key !== 'blogs')
                                    <hr class="my-4"><h3 class="h5">Section items</h3>
                                    @foreach($section->items as $item)
                                        <div class="border rounded p-3 mb-3 bg-light">
                                            <form action="{{ route('admin.content.section-items.update', ['page' => $page->slug, 'section' => $section->id, 'item' => $item->id]) }}" method="post" enctype="multipart/form-data" class="row">
                                                @csrf @method('PUT')
                                                <div class="col-md-6 mb-2"><label class="form-label">Title</label><input class="form-control" name="title" value="{{ $item->title }}"></div>
                                                <div class="col-md-6 mb-2"><label class="form-label">Subtitle</label><input class="form-control" name="subtitle" value="{{ $item->subtitle }}"></div>
                                                <div class="col-md-3 mb-2"><label class="form-label">Display order</label><input class="form-control" type="number" min="0" name="sort_order" value="{{ $item->sort_order }}"><small class="text-muted">Lower numbers display first.</small></div>
                                                @if($section->section_key !== 'safety')
                                                    <div class="col-12 mb-2"><label class="form-label">Content</label><textarea class="form-control" name="body" rows="3">{{ $item->body }}</textarea></div>
                                                    <div class="col-md-6 mb-2"><label class="form-label">Button label</label><input class="form-control" name="button_label" value="{{ $item->button_label }}"></div>
                                                    <div class="col-md-6 mb-2"><label class="form-label">Button URL</label><input class="form-control" name="button_url" value="{{ $item->button_url }}"></div>
                                                @endif
                                                @if($section->section_key !== 'safety')
                                                    <div class="col-md-6 mb-2"><label class="form-label">Image</label><input class="form-control" type="file" name="image" accept="image/jpeg,image/png,image/webp"></div>
                                                    <div class="col-md-6 mb-2"><label class="form-label">Image alt text</label><input class="form-control" name="image_alt" value="{{ $item->image_alt }}"></div>
                                                @endif
                                                <div class="col-12 mb-2"><label class="form-check"><input type="hidden" name="is_enabled" value="0"><input class="form-check-input" type="checkbox" name="is_enabled" value="1" @checked($item->is_enabled)><span class="form-check-label">Display item</span></label></div>
                                                <div class="col-12"><button class="btn btn-sm btn-success" type="submit">Update Item</button></div>
                                            </form>
                                            <form action="{{ route('admin.content.section-items.destroy', ['page' => $page->slug, 'section' => $section->id, 'item' => $item->id]) }}" method="post" class="mt-2" onsubmit="return confirm('Delete this item?')">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger" type="submit">Delete Item</button></form>
                                        </div>
                                    @endforeach

                                    <details class="border rounded p-3">
                                        <summary class="fw-bold">Add section item</summary>
                                        <form action="{{ route('admin.content.section-items.store', ['page' => $page->slug, 'section' => $section->id]) }}" method="post" enctype="multipart/form-data" class="row mt-3">
                                            @csrf
                                            <div class="col-md-6 mb-2"><label class="form-label">Title</label><input class="form-control" name="title"></div>
                                            <div class="col-md-6 mb-2"><label class="form-label">Subtitle</label><input class="form-control" name="subtitle"></div>
                                            @if($section->section_key !== 'safety')
                                                <div class="col-12 mb-2"><label class="form-label">Content</label><textarea class="form-control" name="body" rows="3"></textarea></div>
                                                <div class="col-md-6 mb-2"><label class="form-label">Button label</label><input class="form-control" name="button_label"></div>
                                                <div class="col-md-6 mb-2"><label class="form-label">Button URL</label><input class="form-control" name="button_url"></div>
                                            @endif
                                            @if($section->section_key !== 'safety')
                                                <div class="col-md-6 mb-2"><label class="form-label">Image</label><input class="form-control" type="file" name="image" accept="image/jpeg,image/png,image/webp"></div>
                                                <div class="col-md-6 mb-2"><label class="form-label">Image alt text</label><input class="form-control" name="image_alt"></div>
                                            @endif
                                            <input type="hidden" name="is_enabled" value="1">
                                            <div class="col-12"><button class="btn btn-primary" type="submit">Add Item</button></div>
                                        </form>
                                    </details>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</section>
@endsection
